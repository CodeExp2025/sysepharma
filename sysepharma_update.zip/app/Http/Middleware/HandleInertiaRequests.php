<?php

namespace App\Http\Middleware;

use App\Models\Pharmacy;
use Illuminate\Http\Request;
use Inertia\Middleware;

class HandleInertiaRequests extends Middleware
{
    /**
     * The root template that is loaded on the first page visit.
     *
     * @var string
     */
    protected $rootView = 'app';

    /**
     * Determine the current asset version.
     */
    public function version(Request $request): ?string
    {
        return parent::version($request);
    }

    /**
     * Define the props that are shared by default.
     *
     * @return array<string, mixed>
     */
    public function share(Request $request): array
    {
        $user = $request->user();

        $userPharmacies = [];
        if ($user) {
            $userPharmacies = $user->pharmacies()->get(['pharmacies.id', 'pharmacies.name'])->toArray();
        }

        return [
            ...parent::share($request),
            'auth' => [
                'user'            => $user,
                'roles'           => $user ? $user->getRoleNames()->values() : [],
                'permissions'     => $user ? $user->getAllPermissions()->pluck('name')->values() : [],
                'pharmacies'      => $userPharmacies,
                'active_pharmacy' => $user?->pharmacy,
            ],
        ];
    }
}
